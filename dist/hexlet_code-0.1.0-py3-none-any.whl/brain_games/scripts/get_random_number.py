#!/usr/bin/env python3
import random


def random_number(max=100):
    return random.randint(0, max)

