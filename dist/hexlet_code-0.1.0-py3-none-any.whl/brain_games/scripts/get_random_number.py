#!/usr/bin/env python3
import random


def random_number(max=100, min=0):
    return random.randint(min, max)
